---
name: phong-van-website
description: Phỏng vấn người dùng từng câu một để lập hồ sơ (03-website/ho-so.md), rồi dựng một website một trang về họ, rà thông tin riêng tư trước khi đưa lên mạng. Dùng khi người dùng muốn làm trang giới thiệu bản thân, trang hồ sơ năng lực, trang giới thiệu team hoặc trang tuyển đại lý.
---

# Phỏng vấn rồi dựng website

Skill này đi cùng người dùng suốt Việc 3 của khoá Claude Thực Chiến: phỏng vấn → hồ sơ → dựng trang → rà thông tin → go live.
Luôn trả lời bằng tiếng Việt, xưng "mình", gọi người dùng là "bạn".

## Bước 1 · Phỏng vấn

Quy tắc bắt buộc:
- Hỏi **mỗi lần đúng một câu**, chờ trả lời rồi mới hỏi tiếp.
- Câu trả lời ngắn quá thì hỏi thêm một câu gợi mở (ví dụ: "Có con số nào cho thành tích này không?").
- **Ghi ngay** từng câu trả lời vào `03-website/ho-so.md` theo đúng mục bên dưới, để người dùng dừng giữa chừng cũng không mất gì.
- Nếu `ho-so.md` đã có nội dung: đọc trước, chỉ hỏi những mục còn thiếu.

Thứ tự câu hỏi (khoảng 8–10 câu):
1. Tên hiển thị trên trang.
2. Công việc hiện tại: vai trò, lĩnh vực, bao nhiêu năm kinh nghiệm.
3. Website này dành cho ai (khách hàng, đại lý tiềm năng, đối tác, nhà tuyển dụng…)?
4. Sau khi xem trang, bạn muốn người xem làm gì (gửi email, để lại số điện thoại, đăng ký…)?
5. Hai tới ba thành tích nổi bật, **có con số** nếu được.
6. Một dự án hoặc câu chuyện tiêu biểu: bối cảnh, bạn đã làm gì, kết quả.
7. Kỹ năng hoặc thế mạnh mà người xem nên biết.
8. Phong cách mong muốn (trang trọng, thân thiện, năng động…) và màu sắc yêu thích nếu có.
9. Thông tin liên hệ muốn công khai.

Mẫu `ho-so.md`:

```markdown
# Tên
# Công việc hiện tại
# Website dành cho ai
# Người xem nên làm gì sau khi xem
# Thành tích
# Dự án tiêu biểu
# Kỹ năng, thế mạnh
# Phong cách mong muốn
# Liên hệ (công khai được)
```

Khi đủ thông tin: tóm tắt hồ sơ trong 5 dòng và hỏi người dùng có muốn sửa gì không. **Chưa dựng trang** khi người dùng chưa đồng ý.

## Bước 2 · Kiểm tra trước khi dựng

- [ ] Mỗi thành tích đều lấy từ câu trả lời của người dùng, **không tự bịa số liệu**.
- [ ] Đã rõ người xem là ai và người xem nên làm gì.
- [ ] Đã có ít nhất một cách liên hệ.

## Bước 3 · Dựng trang

- Một trang HTML duy nhất (`index.html`, CSS đặt bên trong), chạy được khi mở trực tiếp, không cần cài gì.
- Ưu tiên hiển thị tốt trên **điện thoại**; chữ tối thiểu 16px; một nút hành động chính rõ ràng.
- Các phần: giới thiệu ngắn · thành tích (có số) · dự án tiêu biểu · thế mạnh · liên hệ.
- Nếu người dùng muốn nhiều phương án: giao cho các trợ lý (sub-agent) dựng song song, mỗi bản một thư mục `ban-1`, `ban-2`, `ban-3`, rồi để người dùng chọn.

## Bước 4 · Rà thông tin trước khi công khai

Trước khi đưa lên mạng, liệt kê cho người dùng mọi thông tin không nên công khai, kèm đề xuất thay thế, **không tự sửa**:
- Thông tin cá nhân: số điện thoại riêng, địa chỉ nhà, ngày sinh.
- Số liệu kinh doanh nội bộ của công ty (doanh thu, chỉ tiêu, hoa hồng).
- Tên khách hàng, đại lý, đối tác chưa được phép nêu tên.

## Bước 5 · Go live (khi người dùng yêu cầu)

- Dùng GitHub Pages với kho `<tên-github>.github.io`. Người dùng **tự đăng nhập** GitHub; không bao giờ hỏi mật khẩu.
- **Không** đưa `ho-so.md` và các thư mục phương án phụ lên kho công khai.
- Hỏi người dùng trước mỗi bước; báo đường link khi trang đã chạy.
